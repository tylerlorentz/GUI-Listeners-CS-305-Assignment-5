package contoller;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Objects;
import java.util.function.IntConsumer;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import model.ColorModel;
import model.PropertyChangeEnabledMutableColor;

/**
 * @author tyler
 * @version autumn 2025
 */

public class ValueRowPanel extends JPanel implements PropertyChangeListener {

    private static final long serialVersionUID = 1L;

    /**
     * New button size.
     */
    private static final Dimension BUTTON_SIZE = new Dimension(26, 26);

    /**
     * New label size.
     */
    private static final Dimension LABEL_SIZE = new Dimension(45, 26);

    /**
     * Field columns for color text.
     */
    private static final int TEXT_FIELD_COLUMNS = 3;

    /**
     * Padding for the container.
     */
    private static final int HORIZONTAL_PADDING = 30;

    /**
     * The color model whose component this panel controls.
     */
    private final PropertyChangeEnabledMutableColor myColorModel;

    /**
     * The property name for panel (PROPERTY_RED, PROPERTY_GREEN, or PROPERTY_BLUE).
     */
    private final String myPropertyName;

    /**
     * Setter method to update the value in the model for this component.
     */
    private final IntConsumer mySetter;

    /**
     * Index in the RGB array: 0=Red, 1=Green, 2=Blue.
     */
    private final int myIndex;

    /**
     * Panel that visually displays the current color component.
     */
    private final JPanel myColorDisplayPanel;

    /**
     * Text field that shows and optionally allows editing of the current value.
     */
    private final JTextField myValueField;

    /**
     * Checkbox that enables or disables editing of the text field.
     */
    private final JCheckBox myEnableEditButton;

    /**
     * Button to increment the color value.
     */
    private final JButton myIncreaseButton;

    /**
     * Button to decrement the color value.
     */
    private final JButton myDecreaseButton;

    /**
     * Slider to adjust the color value.
     */
    private final JSlider myValueSlider;

    /**
     * Array storing current RGB values for building color; index corresponds to myIndex.
     */
    private final int[] myColorComponents = new int[3];

    /**
     * Constructs a row panel for a single color component.
     */

    public ValueRowPanel(final String theLabelText,
                         final int theInitialValue,
                         final IntConsumer theSetter,
                         final PropertyChangeEnabledMutableColor theModel,
                         final String thePropertyName,
                         final int theIndex) {

        super(new FlowLayout(FlowLayout.LEFT));
        myColorModel = theModel;
        myPropertyName = thePropertyName;
        mySetter = theSetter;
        myIndex = theIndex;

        myColorComponents[theIndex] = theInitialValue;

        myColorDisplayPanel = new JPanel();
        myValueField = new JTextField(String.valueOf(theInitialValue), TEXT_FIELD_COLUMNS);
        myEnableEditButton = new JCheckBox("Enable edit");
        myIncreaseButton = new JButton();
        myDecreaseButton = new JButton();
        myValueSlider = new JSlider();

        layoutComponents(theLabelText);
        addListeners();

        myColorModel.addPropertyChangeListener(myPropertyName, this);

        propertyChange(new PropertyChangeEvent(this, myPropertyName, null, theInitialValue));
    }

    private void layoutComponents(final String theLabelText) {
        myColorDisplayPanel.setPreferredSize(BUTTON_SIZE);
        myColorDisplayPanel.setBackground(buildColor());

        final JLabel rowLabel = new JLabel(theLabelText + ": ");
        rowLabel.setPreferredSize(LABEL_SIZE);

        myValueField.setEditable(false);
        myValueField.setColumns(TEXT_FIELD_COLUMNS);
        myValueField.setHorizontalAlignment(JTextField.RIGHT);

        final JPanel rightPanel = new JPanel();
        rightPanel.setBorder(BorderFactory.createEmptyBorder(0,
                HORIZONTAL_PADDING, 0, HORIZONTAL_PADDING));
        rightPanel.setBackground(rightPanel.getBackground().darker());

        myIncreaseButton.setIcon(new ImageIcon("./images/ic_increase_value.png"));
        myIncreaseButton.setPreferredSize(BUTTON_SIZE);

        myValueSlider.setMaximum(ColorModel.MAX_VALUE);
        myValueSlider.setMinimum(ColorModel.MIN_VALUE);
        myValueSlider.setBackground(rightPanel.getBackground());

        myDecreaseButton.setIcon(new ImageIcon("./images/ic_decrease_value.png"));
        myDecreaseButton.setPreferredSize(BUTTON_SIZE);

        rightPanel.add(myDecreaseButton);
        rightPanel.add(myValueSlider);
        rightPanel.add(myIncreaseButton);

        add(myColorDisplayPanel);
        add(rowLabel);
        add(myValueField);
        add(myEnableEditButton);
        add(rightPanel);
    }

    private void addListeners() {
        myValueSlider.addChangeListener(e -> {
            final int value = myValueSlider.getValue();
            myValueField.setText(String.valueOf(value));
            mySetter.accept(value);
        });

        myIncreaseButton.addActionListener(e -> {
            final int value = myValueSlider.getValue();
            myValueSlider.setValue(Math.min(value + 1, myValueSlider.getMaximum()));
        });

        myDecreaseButton.addActionListener(e -> {
            final int value = myValueSlider.getValue();
            myValueSlider.setValue(Math.max(value - 1, myValueSlider.getMinimum()));
        });

        myEnableEditButton.addActionListener(e -> myValueField.
                setEditable(myEnableEditButton.isSelected()));

        myValueField.addActionListener(e -> handleTextFieldInput());
        myValueField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(final FocusEvent theE) {
                handleTextFieldInput();
            }
        });
    }

    private void handleTextFieldInput() {
        final String text = myValueField.getText().trim();
        try {
            final int value = Integer.parseInt(text);
            final int bounded = Math.max(ColorModel.MIN_VALUE,
                    Math.min(value, ColorModel.MAX_VALUE));
            mySetter.accept(bounded);
        } catch (final NumberFormatException ignored) {

        }
        final int current = myColorComponents[myIndex];
        myValueField.setText(String.valueOf(current));
        myValueSlider.setValue(current);
    }

    private Color buildColor() {
        final int[] rgb = new int[]{0, 0, 0};
        rgb[myIndex] = myColorComponents[myIndex];
        return new Color(rgb[0], rgb[1], rgb[2]);
    }

    @Override
    public void propertyChange(final PropertyChangeEvent theEvent) {
        final Integer newVal = Objects.requireNonNullElse((Integer)
                theEvent.getNewValue(), myColorComponents[myIndex]);

        myColorComponents[myIndex] = newVal;

        myValueField.setText(String.valueOf(newVal));
        myValueSlider.setValue(newVal);
        myColorDisplayPanel.setBackground(buildColor());

        myDecreaseButton.setEnabled(Math.max(newVal - myValueSlider.getMinimum(), 0) > 0);
        myIncreaseButton.setEnabled(Math.max(myValueSlider.getMaximum() - newVal, 0) > 0);
    }

}
